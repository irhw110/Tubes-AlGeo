cara menjalankan program 
1. buka terminal 
2. masuk direktori dimana file disimpan
3. jalankan file dengan mengetikkan python3 main.py
4. setelah itu user akan diminta memasukkan input 
ketik 1 untuk memasuki jendela 3D
ketik 2 untuk memasuki jendela 2D
5. Setelah input dimasukkan program akan menampilkan jendela pygame atau pyopengl

Jika user memilih 1 (3D)
1. untuk memperbesar layar tekan pagedown
2. untuk memperkecil layar tekan pageup
3. untuk menggeser angle tekan panah (atas, bawah, kanan, kiri)
4. untuk memasukkan fungsi transformasi tekan f saat di jendela pygame
5. setelah itu ketikkan fungsi (misal : translate 3 3 3)
5. untuk reset objek ketik reset 

Jika user memilih 2 (2D)
1. untuk memperbesar layar tekan panah atas
2. untuk memperkecil layar tekan pageup
4. untuk memasukkan fungsi transformasi tekan f saat di jendela pyopengl
5. setelah itu ketikkan fungsi (misal : translate 3 3)
5. untuk reset objek ketik reset
 
